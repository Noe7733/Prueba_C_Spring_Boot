package com.example.demo.prueba.entity;

import javax.persistence.*;

@Entity
@Table

public class Horarios {

	/*
	@Id   
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id_H")
	public
	*/
	
}
